Copy paste the assets folder in your Unity project
- Run VRPN server
- Run UniVRPNity server
- Run your Unity scene