These examples are obsolete. 
Use examples from other folder.